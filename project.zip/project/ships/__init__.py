# project/ships/__init__.py
from .registry import SHIP_CLASSES